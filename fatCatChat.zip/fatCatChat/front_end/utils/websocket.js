var url = 'ws://127.0.0.1:8080';//服务器地址
function socketConnect(userInfo) {
  wx.connectSocket({
    url: url,
    data: 'data',
    header: {
      'content-type': 'application/json'
    },
    method: 'post',
    success: function (res) {
      console.log('WebSocket连接创建', res)
    },
    fail: function (err) {
      wx.showToast({
        title: '网络出现异常',
      })
      console.log(err)
    },
  })

}


module.exports = {
  socketConnect:socketConnect
}

