var app = getApp();
const util = require('../../utils/util.js')
const socketApi = require("../../utils/websocket.js")
Page({
  data: {
    inputMessage:"",
    userInfo:{},
    currentUserMessage:{},
    remoteUserMessage:{},
    sendMessage:"",
    scrollTop: 0,
  },


  onLoad: function (options) {
    console.log("load page")
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo
      })
    }
  },
  onShow: function () {
    console.log("show page")
    socketApi.socketConnect(this.data.userInfo)
  },

  onReady: function () {
    var that = this
    wx.onSocketMessage(function(res){
      console.log("收到信息")
      var remoteUserMessage = JSON.parse(res.data)
      console.log(remoteUserMessage)
      that.setData({
        remoteUserMessage:remoteUserMessage
      })
    that.bottom()
    })
  },

  bottom: function () {
    var query = wx.createSelectorQuery()
    query.select('#flag').boundingClientRect()
    query.selectViewport().scrollOffset()
    query.exec(function (res) {
      wx.pageScrollTo({
        scrollTop: res[0].bottom  
      })
      res[1].scrollTop  
    })
  },


  onHide: function () {
    console.log("hide")
    console.log()
    wx.closeSocket()
  },
  bindChange:function(e){
    this.setData({
      inputMessage: e.detail.value
    })
  },
  sendMessage:function(){
    console.log("send msg")
    console.log(this.data.inputMessage)
    this.setData({
      sendMessage:this.data.inputMessage
    })
  },
  /**
   * 生命周期函数--监听页面卸载
   */

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  }
})